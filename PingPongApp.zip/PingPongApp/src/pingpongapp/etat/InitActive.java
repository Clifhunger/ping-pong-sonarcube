/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pingpongapp.etat;

import java.io.IOException;
import pingpongapp.Joueur;
import pingpongapp.PDU.Ackinit;

/**
 *
 * @author clifhunger
 */
public class InitActive implements Etat{
    private Joueur joueur;

    public InitActive(Joueur joueur) {
        this.joueur = joueur;
    } 

    @Override
    public String getMessage() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void init() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void attenteAck() {
        // attente de la réponse du serveur
           try
            {
                   System.out.println("Attente de la réponse");
                   Ackinit objet=(Ackinit) joueur.getInput().readObject(); 
                   System.out.println("j'ai reçus la réponse du serveur ");
                   System.out.println(objet);
            }
             catch(Exception e)
                 {
                     e.printStackTrace();
                     System.out.println(e.getMessage());
                 }
         
           joueur.setEtat(joueur.getEtatIlSert());
    }

    @Override
    public void echange() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
