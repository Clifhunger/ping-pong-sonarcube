/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pingpongapp;

import java.io.*;
import java.net.*;
import pingpongapp.etat.*;
/**
 *
 * @author ecossard
 */
public class Serveur extends Joueur {
     public static final int portEcoute = 5555;
     private ServerSocket socketServeur=null;
     private Socket socketClient = null;
    public Serveur()
    {
        super();
        setEtat(super.getEtatRepos());
    }
    public void lancerConnexion()
    {
	try {	
	    socketServeur = new ServerSocket(portEcoute);
	} catch(IOException e) {
	    System.err.println("Creation de la socket impossible : " + e);
	    System.exit(-1); // code retour pour le système
	}
        
         // Attente d'une connexion d'un client
        Socket socketClient = null;
	try {
            System.out.println("Attente de connexion");
	    socketClient = socketServeur.accept();
            System.out.println("Connexion OK");
	} catch(IOException e) {
	    System.err.println("Erreur lors de l'attente d'une connexion : " + e);
	    System.exit(-1); // code retour pour le système
	}  
           // Association d'un flux d'entree et de sortie
           try {
	    input = new ObjectInputStream(socketClient.getInputStream());
	    output = new ObjectOutputStream(socketClient.getOutputStream());

	} catch(IOException e) {
	    System.err.println("Association des flux impossible : " + e);
	    System.exit(-1);
	}
	
    }

     @Override
    public void setEtat(Etat etat) {
       this.etat=etat;
    }

    @Override
    public void close() {
        try{
       input.close();
       output.close();
       socketClient.close();
       socketServeur.close();
        }
       catch(IOException e) {
            System.err.println("Erreur lors de la fermeture des flux et des sockets : " + e);
            System.exit(-1);
        }  
    }


    
    
    
    
}
