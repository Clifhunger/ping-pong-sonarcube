/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pingpongapp;

import java.io.*;
import java.net.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import pingpongapp.etat.*;
/**
 *
 * @author ecossard
 */
public class Client extends Joueur {
    private Socket socket=null;
    
    public Client()
    {
        super();
        setEtat(super.getEtatRepos());
    }
public void lancerConnexion()
{
       Properties ipProps = new Properties();
        FileInputStream in = null;
        try {
            in = new FileInputStream("src\\pingpongapp\\config.properties");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            ipProps.load(in);
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
	try {
	    //socket = new Socket("localhost", pingpongapp.Serveur.portEcoute);
          socket = new Socket(InetAddress.getByName(ipProps.getProperty("app.ip")),5555);
	} 
        catch(UnknownHostException e) {
	    System.err.println("Erreur sur l'hôte : " + e);
	    System.exit(-1);
	} 
        catch(IOException e) {
	    System.err.println("Creation de la socket impossible : " + e);
	    System.exit(-1);
	} 
       try {
            output = new ObjectOutputStream(socket.getOutputStream()); 
            input = new ObjectInputStream(socket.getInputStream()); 

	} catch(IOException e) {
	    System.err.println("Association des flux impossible : " + e);
	    System.exit(-1);
	}
           System.out.println("Connexion OK");  
    
        
}

    @Override
    public void setEtat(Etat etat) {
       this.etat=etat;
    }

    @Override
    public void close() {
        try{
       input.close();
       output.close();
        socket.close();
        }
       catch(IOException e) {
            System.err.println("Erreur lors de la fermeture des flux et des sockets : " + e);
            System.exit(-1);
        }            
    }

 


}
